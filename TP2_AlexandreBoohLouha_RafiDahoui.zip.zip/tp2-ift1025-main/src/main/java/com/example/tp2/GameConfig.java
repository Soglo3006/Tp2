    package com.example.tp2;

    public class GameConfig {
        public static final int WINDOW_WIDTH = 640;
        public static final int WINDOW_HEIGHT = 440;
    }
